# 환생 통계 배치 5 출처

2026-10-13에 받은 원본은 `original/`에 두었다. 이 디렉터리 바로 아래 CSV만 정규화 결과다. 저장소와 배치 1–4 디렉터리는 수정하지 않았다.

공통 규칙:

- `iso3`는 ISO 3166-1 alpha-3만 남겼다. 지역·소득군 합계, 코소보처럼 ISO 코드가 없는 지역, 나라 안 지역(잉글랜드·스코틀랜드 등)은 뺐다. 코드표는 배치 3의 `original/iso3166.csv`를 썼다.
- 빈 값은 넣지 않았고, 연도를 보간하거나 나라 사이를 평균내지 않았다.
- "빈 곳"은 배치 2 `births_by_year.csv`의 237개 코드와 비교한 수다.
- 용량 때문에 압축을 푼 큰 파일(FAOSTAT CSV 2.1GB, StatCan CSV 580MB, SSA·INSEE 풀린 파일)은 정규화 뒤 지웠다. 압축 원본은 그대로 있다.

## 라이선스 요약 (광고 사이트 기준)

| 파일 | 라이선스 | 상업 이용 |
|---|---|---|
| factbook_country_profile.csv | 퍼블릭 도메인(미러는 CC0) | 가능 |
| driving_side_calling_code.csv, famous_people_top30.csv, top_cities.csv, official_symbols_wikidata.csv | CC0 | 가능 |
| national_symbols_wikipedia.csv | **CC BY-SA 4.0** | 가능하지만 출처 표시와 동일조건 공유 의무. CC0 아님 |
| food_supply_per_capita.csv, daily_calorie_supply.csv | CC BY 4.0 (FAOSTAT) | 가능 |
| expected_years_of_schooling.csv | CC BY 3.0 IGO (UNDP), OWID 가공분 CC BY 4.0 | 가능 |
| **smoking_rate.csv, obesity_rate.csv, registered_vehicles_per_1000.csv** | **원자료 WHO GHO는 CC BY-NC-SA 3.0 IGO(비상업)** | **주의: 쓰기 전 확인 필요** |
| **alcohol_consumption.csv** | **WHO 원자료를 세계은행이 재배포. 세계은행은 CC BY 4.0이지만 제3자 지표는 다를 수 있다고 적음** | **불분명** |
| **twin_birth_share.csv** | **Human Multiple Births Database. OWID 메타데이터에 라이선스 항목이 없음** | **불분명** |
| baby_names_top100.csv | 나라별로 다름(아래). 모두 상업 이용 가능한 공개 라이선스 | 가능(출처 표시) |

OWID 메타데이터 JSON 6개 모두에 `license` 필드가 없었다. 위 WHO·UNDP 조건은 원기관의 일반 이용 조건이고, 이번에 조건 원문을 다시 받아 확인하지는 않았다.

## 건너뛴 것 (이전 배치에 이미 있음)

- 연간 노동 시간(`working_hours.csv`), 휴대폰 가입(`mobile_subscriptions.csv`), PM2.5 노출(`air_pollution.csv`), 살인율(`homicide_rate.csv`)은 배치 3에 있어 받지 않았다.
- 중위 연령은 배치 1(`median-age.csv`), 출생 시 성비와 도시화율은 배치 3에 시계열이 있다. Factbook 값은 같은 레코드에 있어 `factbook_country_profile.csv`에 한 시점 값으로만 넣었다. 시계열이 필요하면 이전 배치를 쓴다.

## 받지 못한 것

- **한국 대법원 출생신고 이름 통계.** `https://stfamily.scourt.go.kr/st/StFrrStatcsView.do?pgmId=090000000025`("상위 출생신고 이름 현황", 보고서 ID 1811)는 화면 조회만 된다. 자료 요청(`/ds/report/query.do`)에 난독화된 서명 스크립트(`/ds/dynapath.do`)가 붙어 있어 자동 수집을 막은 것으로 보고 우회하지 않았다. 내려받기 파일도, 이용 조건(공공누리 표시)도 찾지 못했다. `original/names/kor/stfamily-index.html`은 그 화면의 껍데기뿐이다. 공공데이터포털에서 "출생신고 이름" 파일 검색도 결과가 없었다.
- **Wikidata의 국민 음식·국화·국가 동물·국가 스포츠.** 구조화된 진술이 거의 없다. 공식 상징(P2238)이 있는 곳이 21개 코드뿐이고, "national dish" 등 분류로 찾은 항목은 10여 개였다(`original/wikidata/ql-national-items-*.tsv`). 그래서 영어 위키백과 목록 4개를 대신 받았다(CC BY-SA 4.0, 아래).
- **Factbook의 자동차 통행 방향과 전화 국가번호.** 현행 Factbook 항목에 없다. Wikidata 값으로 대신했다.
- **자동차 보유(승용차만).** OWID에서 찾은 것은 WHO의 "등록 차량 전체"(이륜차·화물차 포함)이고 나라마다 한 해 값뿐이다.
- 미국 SSA 원 주소 `https://www.ssa.gov/oact/babynames/names.zip`는 HTTP 403이었다. Wayback Machine이 2026-10-10에 저장한 같은 파일을 받았다.
- 영국은 최신 1개 연도 파일만 받았다. 캐나다·호주는 아래 범위 주의를 본다.

## factbook_country_profile.csv

- 열: `iso3,factbook_code,factbook_name,capital,currency_name,currency_code,climate,terrain,highest_point,highest_point_m,national_holiday,national_symbols,national_colors,military_service,military_min_age,conscription_keyword,median_age_total,median_age_year,median_age_male,median_age_female,sex_ratio_at_birth,urban_pct,urban_year,internet_tld`. 행 242, 코드 242. 한 시점 값(항목마다 2023–2026년 추정).
- 출처: CIA World Factbook의 JSON 미러 `https://github.com/factbook/factbook.json` (받은 주소 `https://codeload.github.com/factbook/factbook.json/zip/refs/heads/master`, 커밋 `144d6977`, 파일 날짜 2026-09-11). 원본은 `original/factbook/`.
- 라이선스: Factbook 본문은 미국 정부 저작물로 퍼블릭 도메인, 미러 저장소는 CC0 1.0.
- 코드 변환: Factbook 파일명은 GEC(옛 FIPS) 코드다. Wikidata P901로 ISO3에 맞추고, 빠지거나 겹친 14개는 파일 안 나라 이름을 보고 손으로 맞췄다(러시아 rs, 세르비아 ri, 몬테네그로 mj, 남수단 od, 동티모르 tt, 네덜란드 nl, 퀴라소 uc, 신트마르턴 nn, 생마르탱 rn, 생바르텔레미 tb, 스발바르 sv→SJM, 미국령 군소 제도 um, 서안 we→PSE). 가자지구(gz)는 서안과 같은 PSE라 뺐다. 코소보·아크로티리·데켈리아·얀마옌 등 ISO3가 없는 12곳도 뺐다.
- 채워진 수(242행 중): 수도 231, 통화 이름 220·코드 214, 기후 242, 지형 241, 최고점 242(미터 값 239), 국경일 230, 국가 상징 227, 국가 색 217, 병역 176, 중위 연령 228, 출생 시 성비 226, 도시화율 228, 도메인 240.
- 빈 곳: 237개 가운데 7곳(BES, GLP, GUF, MTQ, MYT, REU, 코소보). 프랑스 해외 레지옹은 Factbook이 프랑스에 합쳐 다룬다.
- 주의:
  - 통화는 "환율" 항목에서 뽑았다. 미국처럼 환율 항목이 없는 나라는 비어 있다(237개 기준 21곳).
  - `conscription_keyword`(yes/no)는 병역 문장에 compulsory·mandatory·conscript 낱말이 있는지 본 **기계 판정**이다. 네덜란드처럼 "제도는 남아 있으나 소집 정지"인 나라가 yes로 나온다. 화면에 쓰기 전에 `military_service` 원문을 읽어야 한다. `military_min_age`도 문장의 첫 두 자리 수일 뿐이다.
  - `national_symbols`는 동물·꽃·문장이 한 문장에 섞인 자유 서술이다(한국: 태극, 무궁화, 시베리아호랑이).
  - `highest_point`에는 설명이 붙은 나라가 있다. `highest_point_m`은 첫 미터 값이다.

## driving_side_calling_code.csv

- 열: `iso3,wikidata_qid,driving_side,calling_code,internet_tld`. 행 249. 통행 방향 246, 국가번호 242, 도메인 247. 연도 없음.
- 출처: Wikidata SPARQL `https://query.wikidata.org/sparql`. P298(ISO3), P1622(통행 방향), P474(국가번호), P78(최상위 도메인). 원본 `original/wikidata/wd-country-codes.json`.
- 라이선스: CC0 1.0.
- 주의: 값이 여럿이면 `|`로 이었다. 아르헨티나가 `left|right`로 나오는데(과거 값이 남은 것으로 보임) 실제는 우측이다. 화면에 쓰기 전 `|`가 있는 행은 확인한다.

## famous_people_top30.csv

- 열: `iso3,rank,name,name_ko,wikidata_qid,sitelinks,birth_year,sex,occupations`. 행 6,409, 코드 220. 출생 연도 -2350–2020.
- 출처: Wikidata(CC0). 사람(P31=Q5)의 출생지(P19)가 속한 나라(P17)를 기준으로 sitelinks 수가 많은 순 30명. 대량 질의는 Wikidata 덤프를 그대로 싣는 QLever(`https://qlever.dev/api/wikidata`)로 했다. 질의문은 `original/wikidata/*.rq`, 결과는 `ql-humans-by-birth-country.tsv`(상위 70만 행), `ql-humans-small-countries.tsv`, 이름·성별·직업은 `people-details/`.
- 채워진 수: 영어 이름 6,322, 한국어 이름 4,530, 출생 연도 6,358, 직업 6,354.
- 30명 미만: AIA 15, ASM 12, GIB 18, HKG 2, IOT 2, MSR 23, NIU 25, PRI 17, SHN 15, SXM 25, VAT 13, VGB 2. 빈 곳 18(주로 프랑스·미국 속령, 마카오, 코소보).
- 주의:
  - "태어난 나라"는 **출생지가 지금 속한 나라**다. 쾨니히스베르크에서 태어난 칸트는 러시아로 잡힌다. 홍콩·푸에르토리코 출생자는 대부분 중국·미국으로 들어간다.
  - sitelinks는 위키백과 말고 다른 위키 프로젝트 문서도 센다. 유명도와 어긋나는 사람이 있다(한국 1위가 성재기 185개, 2위 반기문 153개).
  - 직업은 Wikidata에 적힌 것을 모두 `|`로 이었다. 대표 직업 하나를 고르지 않았다.

## top_cities.csv

- 열: `iso3,rank,city,wikidata_qid,population`. 행 1,608, 코드 208. 연도 없음(Wikidata의 현재 값).
- 출처: Wikidata(CC0), QLever로 질의. "도시(Q515)와 그 하위 분류"인 항목의 인구(P1082). 원본 `original/wikidata/ql-cities-population.tsv`.
- 주의:
  - 10곳을 못 채운 코드가 74개다. 빈 곳 29. **네덜란드가 통째로 없다**(네덜란드 도시들이 "도시" 분류 밑에 걸리지 않음).
  - 광역권·자치구가 섞인다. 미국에 New York metropolitan area, Queens, Manhattan, El Paso–Juárez가 들어 있고 프랑스에 Metropolis of Lyon이 있다. 인구 기준 연도도 도시마다 다르다. 한 도시에 인구 값이 여럿이면 가장 큰 값을 썼다.
  - 출생 상위국은 쓰기 전에 눈으로 걸러야 한다.

## official_symbols_wikidata.csv

- 열: `iso3,symbol,wikidata_qid,role,instance_of`. 행 50, 코드 21.
- 출처: Wikidata P2238(공식 상징), CC0. 원본 `original/wikidata/wd-official-symbols.json`.
- 21개 코드뿐이라 단독으로 쓰기 어렵다. 한국은 없다.

## national_symbols_wikipedia.csv (국민 음식·국화·국가 동물·국가 스포츠)

- 열: `iso3,kind,order,name,note,wikipedia_page,revision_id`. 행 846, 코드 194.
  - `dish` 418행, 169개 코드
  - `animal` 211행, 118개 코드 (`note`에 national bird 등 구분과 학명)
  - `flower` 130행, 93개 코드 (`note`는 문서의 첫 문장)
  - `sport` 87행, 70개 코드 (`note`에 official / unofficial)
- 출처: 영어 위키백과 `National dish`(판 1378343019), `List of national flowers`(1377321774), `List of national animals`(1379858579), `National sport`(1368449071). MediaWiki API `action=parse`로 받은 원본이 `original/wikipedia/`에 있다.
- 라이선스: **CC BY-SA 4.0.** 상업 이용은 되지만 출처 표시가 필요하고, 가공본도 같은 조건으로 공개해야 한다. Wikidata(CC0)와 조건이 다르다.
- 주의: 공식 지정이 아닌 "흔히 그렇게 부른다" 수준이 많다. 음식은 한 나라에 여러 개가 순서 없이 나열된다(한국: 김치, 불고기, 비빔밥, 짜장면, 빙수, 떡볶이). 꽃 이름은 문단 안 링크에서 뽑아 엉뚱한 링크가 섞일 수 있다. 잉글랜드·스코틀랜드·웨일스·카탈루냐 등은 뺐다.

## food_supply_per_capita.csv

- 열: `iso3,year,item,fao_item_code,kg_per_capita_per_year,series`. 행 191,911, 코드 188. 연도 1961–2023.
- 품목 18개: `coffee, tea, rice, wheat, meat_bovine, meat_mutton_goat, meat_pig, meat_poultry, meat_other, meat_total, fish_seafood, sugar_raw_equivalent, sugar_and_sweeteners, alcoholic_beverages, beer, wine, milk_excl_butter, eggs`. 품목마다 10,450–10,700행, 187–188개 코드. 차·우유·달걀·맥주·와인은 요청에 없었지만 같은 파일에 있어 함께 뽑았다.
- 출처: FAOSTAT Food Balance Sheets. 요소 645 "Food supply quantity (kg/capita/yr)".
  - `https://bulks-faostat.fao.org/production/FoodBalanceSheets_E_All_Data_(Normalized).zip` (2010–2023, 파일 날짜 2025-10-14) → `series=fbs_2010_onward`
  - `https://bulks-faostat.fao.org/production/FoodBalanceSheetsHistoric_E_All_Data_(Normalized).zip` (1961–2013, 파일 날짜 2024-02-05) → `series=fbs_historic_1961_2013`
- 라이선스: CC BY 4.0 (FAO 통계 데이터베이스 이용 조건).
- 주의:
  - **두 계열은 방법이 달라 이어 붙이면 안 된다.** 2010–2013년은 두 값이 다 있다. 한국 쌀 2013년이 새 계열 130.21kg, 옛 계열 85.18kg이다(쌀 품목 코드도 2807과 2805로 다르다).
  - 공급량이지 실제 섭취량이 아니다. 술은 제품 무게(kg)라 순수 알코올 리터와 다르다.
  - 중국은 본토(M49 156)만 CHN으로 넣고 합계 "China"(159)는 뺐다. 소련·유고슬라비아·체코슬로바키아 등 사라진 나라와 지역 합계는 뺐다.
  - 빈 곳 49(작은 섬나라·속령, 그리고 싱가포르처럼 FAO 표에 없는 나라).

## daily_calorie_supply.csv

- 열: `iso3,year,kcal_per_capita_per_day,series`. 행 10,700, 코드 188. 연도 1961–2023.
- 출처·라이선스·주의는 위와 같다. 품목 2901 "Grand Total", 요소 664 "Food supply (kcal/capita/day)".

## smoking_rate.csv

- 열: `iso3,year,value`. 단위는 성인 중 담배 사용자 비율(%, 연령 표준화, 남녀 합계). 행 1,503, 코드 167. 연도 2000–2024(몇 해 간격). 빈 곳 70.
- 주소: `https://ourworldindata.org/grapher/share-of-adults-who-smoke.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `tobacco_use_pct_age_std__sex_both_sexes`.
- 출처: World Health Organization, Global Health Observatory (2026), OWID minor processing.
- 라이선스: OWID 가공분 CC BY 4.0. **원자료 WHO GHO는 CC BY-NC-SA 3.0 IGO(비상업).**

## obesity_rate.csv

- 열: `iso3,year,value`. 단위는 18세 이상 성인 중 BMI 30 이상 비율(%, 조율). 행 8,955, 코드 199. 연도 1980–2024. 빈 곳 38.
- 주소: `https://ourworldindata.org/grapher/share-of-adults-defined-as-obese.csv?...`. 열 `obesity_among_adults__bmi__gt__30_kg_m2__crude_estimate__pct__sex_both_sexes__age_group_18plus__years_of_age`.
- 출처·라이선스: 위 흡연율과 같다(WHO GHO, **비상업 조건 주의**).

## alcohol_consumption.csv

- 열: `iso3,year,value`. 단위는 15세 이상 1인당 연간 순수 알코올 리터(추정). 행 3,891, 코드 187. 연도 2000–2020. 빈 곳 50.
- 주소: `https://ourworldindata.org/grapher/total-alcohol-consumption-per-capita-litres-of-pure-alcohol.csv?...`. 열 `sh_alc_pcap_li`.
- 출처: WHO Global Health Observatory, 세계은행 World Development Indicators 경유(지표 SH.ALC.PCAP.LI), OWID 가공.
- 라이선스: **불분명.** 세계은행 조건은 CC BY 4.0이되 제3자 지표는 다를 수 있다. 원자료는 WHO다.

## twin_birth_share.csv

- 열: `iso3,year,value`. 단위는 분만 100건당 쌍둥이 분만 수(%). 행 2,436, **코드 23개뿐**(AUS, AUT, CAN, CHE, CHL, CZE, DEU, DNK, ESP, FIN, FRA, GRC, ISL, ITA, JPN, KOR, LTU, NLD, NOR, NZL, SWE, URY, USA). 연도 1815–2022(나라마다 다름).
- 주소: `https://ourworldindata.org/grapher/rate-of-twin-deliveries.csv?...`. 열 `twinning_share`.
- 출처: Human Multiple Births Database v.1 (2024), OWID 가공.
- 라이선스: **불분명.** OWID 메타데이터에 원자료 라이선스가 없다. HMBD 사이트의 이용 조건을 확인해야 한다.
- 주의: 사산을 포함하는 나라와 아닌 나라가 섞여 있다고 메타데이터가 적는다. 잉글랜드·웨일스, 스코틀랜드 계열은 ISO3가 없어 뺐다.

## expected_years_of_schooling.csv

- 열: `iso3,year,value`. 단위는 년. 행 6,310, 코드 195. 연도 1990–2023. 빈 곳 42.
- 주소: `https://ourworldindata.org/grapher/expected-years-of-schooling.csv?...`. 열 `eys__sex_total`.
- 출처: UNDP, Human Development Report (2025), OWID minor processing.
- 라이선스: UNDP HDR 자료는 CC BY 3.0 IGO, OWID 가공분 CC BY 4.0.

## registered_vehicles_per_1000.csv

- 열: `iso3,year,value`. 단위는 인구 1,000명당 등록 차량 수. 행 161, 코드 161. **나라마다 한 해 값뿐**이고 연도는 2007–2017이다. 빈 곳 76.
- 주소: `https://ourworldindata.org/grapher/registered-vehicles-per-1000-people.csv?...`. 열 `number_of_registered_vehicles_per_thousand`.
- 출처: WHO Global Health Observatory (2026), 인구는 OWID가 여러 출처로 계산.
- 라이선스: **원자료 WHO GHO는 CC BY-NC-SA 3.0 IGO(비상업).**
- 주의: 승용차만이 아니라 이륜차·화물차를 포함한 등록 차량 전체다. 오래된 값이다.

## baby_names_top100.csv (이름 보강)

- 열: `iso3,year,sex,rank,name,count,scope,source`. 행 92,787, 코드 6. 연도 1880–2025. 나라·연도·성별마다 100위까지(동률은 같은 순위). 원본에는 100위 밖 이름도 있다.
- 배치 4 `common_names.csv`(Wikidata 인물 기준)와 달리 **실제 신생아 등록 통계**다.

| iso3 | 범위 | 연도 | 행 | 출처 | 라이선스 |
|---|---|---|---|---|---|
| USA | 전국 | 1880–2025 | 29,209 | SSA `names.zip` (Wayback 2026-10-10 사본, `https://web.archive.org/web/20261010211856id_/https://www.ssa.gov/oact/babynames/names.zip`) | 퍼블릭 도메인(미국 정부 저작물) |
| FRA | 전국 | 1900–2025 | 25,292 | INSEE Fichier des prénoms 2025, `https://www.insee.fr/fr/statistiques/fichier/8595130/prenoms-2025-nat_csv.zip` | Licence Ouverte 2.0 (상업 이용 가능, 출처 표시) |
| NOR | 전국 | 1945–2025 | 16,277 | SSB 표 10467, `https://data.ssb.no/api/v0/en/table/10467` | NLOD / CC BY 4.0 |
| AUS | **뉴사우스웨일스주만** | 1952–2025 | 14,801 | NSW Births Deaths & Marriages, `https://data.nsw.gov.au/data/dataset/a677cbe2-91e1-4e45-b771-08830d3d9e41` | CC BY |
| CAN | 전국 | 1991–2025 | 7,008 | Statistics Canada 표 17-10-0147-01, `https://www150.statcan.gc.ca/n1/tbl/csv/17100147-eng.zip` | Statistics Canada Open Licence (상업 이용 가능, 출처 표시) |
| GBR | **잉글랜드·웨일스만** | 2025 한 해 | 200 | ONS Baby names in England and Wales, 2025 남아·여아 파일 | Open Government Licence v3.0 |

- 주의:
  - 호주는 전국 통계가 없어 주 하나만 받았다. 영국은 스코틀랜드·북아일랜드가 빠져 있고 한 해뿐이다. `scope` 열에 적혀 있다.
  - 미국 SSA는 사회보장카드 신청 기준이고 5건 미만 이름은 빠진다. 노르웨이는 1945년 이전에 비율만 있어 건수가 있는 해부터 넣었다. 프랑스는 희귀 이름 묶음(`_PRENOMS_RARES`)을 뺐다.
  - 캐나다·프랑스·노르웨이·호주 원본은 이름이 전부 대문자라 첫 글자만 대문자로 바꿨다. 악센트가 원본에 없는 이름은 그대로다(프랑스는 2025판에 악센트가 있다).
  - 한국은 받지 못했다(위 "받지 못한 것").
