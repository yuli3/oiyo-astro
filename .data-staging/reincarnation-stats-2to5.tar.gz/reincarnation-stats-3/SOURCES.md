# 환생 통계 배치 3 출처

2026-10-13에 받은 원본은 `original/`에 그대로 두었다. 이 디렉터리 바로 아래 CSV만 정규화 결과다. 저장소와 배치 1·2 디렉터리는 수정하지 않았다.

공통 규칙:

- 열은 `iso3,year,value`다. `adult_height.csv`와 `age_first_marriage.csv`만 `sex`가, `religion.csv`만 `religion`이 추가된다.
- `iso3`는 `^[A-Z]{3}$`만 남겼다. OWID의 `OWID_*` 지역 합계, 세계은행 region id가 `NA`인 집계, UNDP의 발전 수준·지역 행은 뺐다.
- 빈 값은 넣지 않았고, 연도를 보간하거나 나라 사이를 평균내지 않았다.
- 단위 변환은 두 곳뿐이다. UN WPP 인구(천 명)에 1000을 곱해 사람 수로 바꿨고, 세계은행 PIP 빈곤 비율(0–1)에 100을 곱해 퍼센트로 바꿨다. 둘 다 자리수를 새로 만들지 않는 정확한 배수다.
- Our World in Data가 직접 가공한 부분의 라이선스는 OWID FAQ 기준 CC BY 4.0이다. 원 제공자 라이선스가 grapher 메타데이터에 없으면 그렇다고 적고 지어내지 않았다.

배치 1과 같은 OWID 차트에서 다시 자른 것은 24번의 1950년 이전 기대수명·아동사망뿐이다. 1950년 이후는 넣지 않았다.

## 받은 뒤 정규화에 쓰지 않은 것

- Maddison Project Database 2023 원본 xlsx. Dataverse API `https://dataverse.nl/api/datasets/:persistentId/?persistentId=doi:10.34894/INZBF2` 가 HTTP 500이었다. `gdp_per_capita.csv`는 OWID grapher를 썼다.
- NCD-RisC 키 다운로드 페이지는 HTTP 421 또는 연결이 끊겼다. 신장은 OWID grapher를 썼다.
- Pew Research의 2010·2020 종교 구성 원자료는 계정이 필요하다. 로그인하지 않았고, OWID grapher를 썼다.
- `ourworldindata.org/grapher/homicide-rate.csv` 는 HTTP 403이었다. 그 차트는 IHME 대인 폭력이지 UNODC 살인율이 아니다.
- ILO `SDG_A871_SEX_AGE_RT` 는 나중에 받아 `original/ilo-SDG_A871_SEX_AGE_RT.csv`에 있다. 지표 이름이 “경제활동에 참여한 아동 비율”이라 아동노동(경제활동과 가사노동)이 아니다. `child_labor.csv`에 넣지 않았다. 세계은행 `SL.TLF.0714.ZS`(7–14세)와 OWID `children-aged-5-17-engaged-in-labor`도 같은 이유로 쓰지 않았다.
- OWID `maternal-mortality`(1985년 이전에 Gapminder·WHO 사망등록을 이어 붙인 시계열)는 쓰지 않았다. 요청은 WHO/UN MMEIG다.
- OWID 극빈 차트는 점을 빼 한 줄로 만든 가공본이라 쓰지 않았다. PIP 조사 값을 썼다.
- 자살은 연령표준화 성별 합산만 썼다. WHO GHE 모든 연령 사망률과 WHO Mortality Database 보고율은 쓰지 않았다.
- 자연재해 사망 *수* 차트, WHO GHE 재해 사망률, IHME GBD 재해 사망률은 쓰지 않았다. 출력은 EM-DAT를 OWID가 10만 명당으로 발표한 열이다. 건수를 인구로 나눠 직접 만들지 않았다.
- 모성 연령은 WPP의 MAC만 썼다. OWID `period-average-age-of-mothers`에 있는 1950년 이전 Human Fertility Database 연결은 섞지 않았다.

## population.csv

- 열: `iso3,year,value`. 단위는 사람 수.
- 행 72,553. 코드 239개. 연도 −10000–2100.
- 1950년 미만 36,766행은 OWID `population`의 `population_historical`이다. 주소: `https://ourworldindata.org/grapher/population.csv?v=1&csvType=full&useColumnShortNames=true`. 출처는 HYDE v3.3(기원전 10000년–1799), Gapminder v7(1800–1949), OWID의 major processing이다. 음수 연도 1,709행은 그대로 두었다. OWID 가공분은 CC BY 4.0. HYDE·Gapminder 라이선스는 이 메타데이터에 다시 적혀 있지 않다.
- 1950–2100년 35,787행은 UN WPP 2024 medium의 `TPopulation1July`(7월 1일, 천 명)에 1000을 곱한 값이다. 원본: `https://population.un.org/wpp/assets/Excel%20Files/1_Indicator%20(Standard)/CSV_FILES/WPP2024_Demographic_Indicators_Medium.csv.gz`. Country/Area, ISO3가 있는 237개 지역, Medium만. 1950–2100은 나라마다 값이 비어 있지 않다. 2101년은 237개 나라 모두 인구·출산율·출생성비·모성연령이 비어 있어 뺐다.
- 토고는 `https://population.un.org/wpp/assets/Excel%20Files/1_Indicator%20(Standard)/WPP2024_CSV_files_update.zip` 안의 `WPP2024_Demographic_Indicators_Medium_Update.csv`로 1950–2100 전부 덮었다. 업데이트 파일은 토고만 151년이다. 원래 파일과 비교하면 인구 137년, 합계출산율 148년이 다르고 출생성비·모성연령은 같다. 프랑스 1950년은 41,883.119천 명 → 41,883,119명이다.
- 인용: United Nations, Department of Economic and Social Affairs, Population Division (2024). World Population Prospects 2024, Online Edition. 내려받은 CSV 안에는 라이선스 문장이 없다. Summary of Results(UN DESA/POP/2024/TR/NO. 9)는 그 간행물의 그림과 표를 CC BY 3.0 IGO로 재생산할 수 있다고 적는다.
- 1950년 전후를 평균내지 않았다. OWID `population-with-un-projections`는 쓰지 않았다.

## fertility_rate.csv

- 열: `iso3,year,value`. 단위는 여자 1명당 출생아 수(TFR).
- 행 35,787. 코드 237개. 연도 1950–2100.
- 출처·파일·판·토고 덮어쓰기는 `population.csv`의 WPP 2024 medium과 같다. 열은 `TFR`. 빈 값 없음.
- 라이선스 서술은 population의 WPP 항과 같다.

## sex_ratio_at_birth.csv

- 열: `iso3,year,value`. 단위는 여아 100명당 남아 수.
- 행 35,787. 코드 237개. 연도 1950–2100.
- WPP 2024 medium 열 `SRB`. 토고 업데이트와 원래 값이 같다. 빈 값 없음.
- 라이선스 서술은 population의 WPP 항과 같다. 한국 1950년은 106.2다.

## urban_share.csv

- 열: `iso3,year,value`. 단위는 퍼센트.
- 행 17,936. 코드 236개. 연도 1950–2025.
- 주소: `https://ourworldindata.org/grapher/share-of-population-urban.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `share__area_type_urban__data_type_estimates`.
- 출처: United Nations Department of Economic and Social Affairs, Population Division (2025), World Urbanization Prospects 2025, Percentage Urban and Rural by National Definition. OWID minor processing. OWID 가공분은 CC BY 4.0. UN 라이선스 문장은 grapher 메타데이터에 없다.
- 도시 정의는 나라 통계청 기준이라 나라 사이 비교에 주의가 필요하다. 이 CSV에는 2050년까지의 전망 열이 없다. 세계은행 `SP.URB.TOTL.IN.ZS` zip은 `original/`에만 있고, 2025년판 WUP 그래프를 썼기 때문에 출력에 쓰지 않았다.

## maternal_mortality.csv

- 열: `iso3,year,value`. 단위는 출생아 10만 명당 모성사망.
- 행 7,605. 코드 195개. 연도 1985–2023.
- 주소: `https://ourworldindata.org/grapher/maternal-mortality-ratio-who-gho.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `maternal_mortality_ratio__per_100_000_live_births`.
- 출처: World Health Organization, Global Health Observatory (2026). OWID minor processing, CC BY 4.0. WHO 라이선스는 메타데이터에 다시 적혀 있지 않다. 이 열이 UN MMEIG 모성사망비다.
- 세계은행 `SH.STA.MMRT` zip은 받아 두기만 했다.

## extreme_poverty.csv

- 열: `iso3,year,value`. 단위는 퍼센트.
- 행 2,391. 코드 171개. 연도 1963–2025. 이 중 2024년 25행, 2025년 4행.
- 주소: `https://api.worldbank.org/pip/v1/pip?country=all&year=all&povline=3&fill_gaps=false&welfare_type=all&reporting_level=national&format=csv`.
- 출처: World Bank Poverty and Inequality Platform. 국제빈곤선은 2021년 PPP 기준 하루 3.00달러다. 받은 2,479행은 모두 `poverty_line=3`, `reporting_level=national`, `is_interpolated=FALSE`, `estimation_type=survey`다.
- 라이선스: 세계은행 데이터셋 이용 조건은 따로 표시되지 않은 데이터셋에 CC BY 4.0을 적용한다. 추가 분쟁 조항이 있다. `https://www.worldbank.org/ext/en/legal/terms-conditions/datasets` (페이지 표기 Last Updated: Mar 23, 2018).
- 같은 나라-연도에 소득과 소비가 같이 있는 경우가 88개다. 평균내지 않고 소비를 남겼다. 결과는 소비 958행, 소득 1,433행이다.
- `headcount`는 비율이다. 앙골라 2000년 소비 0.269546382606은 26.9546382606으로 뒀다.
- `year`는 `reporting_year`다. `survey_year`가 이와 다른 행이 276개다. 앙골라 2000년의 survey_year는 2000.21이다. 소수 연도로 바꾸지 않았다.
- 2024·2025도 파일은 survey로 표시한다. 지금캐스트로 다시 분류하지 않았다.

## gdp_per_capita.csv

- 열: `iso3,year,value`. 단위는 2011년 가격 국제 달러.
- 행 20,934. 코드 165개. 연도 1–2022.
- 주소: `https://ourworldindata.org/grapher/gdp-per-capita-maddison-project-database.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `gdp_per_capita`.
- 출처: Bolt and van Zanden, Maddison Project Database 2023. OWID minor processing, CC BY 4.0. Maddison 쪽 라이선스 문장은 grapher 메타데이터에 없다. 원본 xlsx는 위 실패 항목대로 받지 못했다.
- 나라 이름만 보고 ISO 코드를 만들지 않았다.

## electricity_access.csv

- 열: `iso3,year,value`. 단위는 인구 대비 퍼센트.
- 행 6,747. 코드 216개. 연도 1990–2024. zip의 연도 칸은 1960–2025이나 값이 있는 해만 남았다.
- 주소: `https://api.worldbank.org/v2/country/all/indicator/EG.ELC.ACCS.ZS?downloadformat=csv`. WDI last updated 2026-10-08.
- 지표명: Access to electricity (% of population). 제공: SDG 7.1.1 Electrification Dataset, World Bank. 메타데이터는 ESMAP에서 받았고 date published 2023, date accessed 2024-05-16이라고 적는다.
- 라이선스: 세계은행 데이터셋 CC BY 4.0(위 PIP 항의 조건 페이지). zip 안에 다른 라이선스 표기는 보이지 않았다.
- 집계 경제는 뺐다. ISO 3166 alpha-3 목록에 없는 `CHI`(Channel Islands), `XKX`(Kosovo)는 세계은행 경제로 남아 있어 유지했다.

## safe_water.csv

- 열: `iso3,year,value`. 단위는 퍼센트.
- 행 3,991. 코드 163개. 연도 2000–2024.
- 주소: `https://ourworldindata.org/grapher/proportion-using-safely-managed-drinking-water.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `wat_sm__residence_total`.
- 출처: WHO/UNICEF Joint Monitoring Programme for Water Supply, Sanitation and Hygiene (2025), JMP 2000–2024. OWID processing, CC BY 4.0. JMP 라이선스는 메타데이터에 다시 적혀 있지 않다.
- 세계은행 `SH.H2O.SMDW.ZS` zip은 받아 두기만 했다.

## undernourishment.csv

- 열: `iso3,year,value`. 단위는 퍼센트. 검열된 값은 문자열 `<2.5`다.
- 행 4,014. 코드 169개. 연도 2001–2024. 이 중 `<2.5`가 1,205행이다.
- 주소: `https://nsi-release-ro-statsuite.fao.org/rest/data/FAO,DF_SDG_2_1_1,1.0/all?dimensionAtObservation=AllDimensions&format=csv`.
- 출처: FAO SDG 2.1.1. `SERIES=SN_ITK_DEFC`, `UNIT_MEASURE=PT`(유병률). 인원 수 계열 `SN_ITK_DEFCN`은 쓰지 않았다. `REF_AREA_TYPE=3`이고 ISO3가 있는 행만. 성별·연령은 모두 `_T`다.
- 라이선스 문장은 이 CSV에 없다.
- 4,014행 모두 `TIME_DETAIL`이 `TIME_PERIOD`와 다르다. 스페인 2001년은 `TIME_DETAIL=2000-2002`다. 발표된 `TIME_PERIOD`를 연도로 두었고, 구간을 한 해로 다시 계산하지 않았다.
- `OBS_STATUS`는 모두 `E`다. CSV가 이 코드의 뜻을 풀어 적지는 않는다. `<2.5`를 2.5로 바꾸지 않았다.

## child_stunting.csv

- 열: `iso3,year,value`. 단위는 퍼센트. 5세 미만, 신장 대비 연령 −2 표준편차 미만, 남녀 합계.
- 행 1,130. 코드 163개. 연도 1983–2024.
- 주소: `https://ourworldindata.org/grapher/share-of-children-younger-than-5-who-suffer-from-stunting.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `stunting_prevalence_among_children_under_5_years_of_age__pct_height_for_age__lt__2_sd__survey_based_estimates__sex_both_sexes`.
- 출처: World Health Organization, Global Health Observatory (2026). 조사 기반 추정치. OWID minor processing, CC BY 4.0. WHO 라이선스는 메타데이터에 다시 적혀 있지 않다.
- 같은 파일의 GDP·인구 열은 무시했다. 저신장 값이 빈 칸인 나라-연도 5,928개는 넣지 않았다. 조사 점을 연도별로 메우지 않았다. JME의 연간 모형 시계열은 찾지 못했다. 세계은행 `SH.STA.STNT.ZS` zip은 받아 두기만 했다.

## child_labor.csv

- 열: `iso3,year,value`. 단위는 퍼센트. 5–17세, 남녀 합계, 경제활동과 가사노동을 함께 보는 아동노동이다.
- 행 96. 코드 96개. 연도 2010–2025. 나라마다 한 해뿐이다.
- 주소: `https://sdmx.data.unicef.org/ws/public/sdmxapi/rest/data/UNICEF,PT,1.0/.PT_CHLD_5-17_LBR_ECON-HC......?format=csv`. HDX 리소스 `1d4ae368-3eaf-4ca0-9608-6ac4600129a6`가 이 주소를 가리킨다. 데이터셋: `https://data.humdata.org/dataset/unicef-pt-chld-5-17-lbr-econ-hc`.
- 지표 `PT_CHLD_5-17_LBR_ECON-HC`. 남긴 행은 `SEX=_T`, `AGE=Y5T17`, 거주·자산 분위도 `_T`다. 다른 연령 구간(Y5T14, Y7T17, Y10T17)은 빼 두었다.
- 출처: UNICEF Data and Analytics, ILO와 공동 계산이 행의 `DATA_SOURCE`에 적힌 조사들. HDX 라이선스는 Creative Commons Attribution for Intergovernmental Organisations (CC BY-IGO)다.
- `OBS_STATUS`는 RA 63행, RP 33행이다. CSV가 코드 뜻을 풀어 적지 않아 둘 다 남겼다.
- 25행은 `COVERAGE_TIME`이 `TIME_PERIOD`와 다르다(예: 2019-20). 연도는 파일의 `TIME_PERIOD`다.
- 모든 행의 각주: 정의, 연령, 문항이 바뀌어 시계열 비교가 어렵기 때문에 UNICEF 글로벌 데이터베이스는 이 지표의 추세 자료를 넣지 않는다고 적는다. 그래서 이 파일은 나라별 한 시점이다.
- ILO 경제활동 지표로 빈 나라를 채우지 않았다.

## homicide_rate.csv

- 열: `iso3,year,value`. 단위는 인구 10만 명당 고의적 살인.
- 행 4,206. 코드 199개. 연도 1990–2024.
- 주소: `https://ourworldindata.org/grapher/homicide-rate-unodc.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `value__category_total__sex_total__age_total__unit_of_measurement_rate_per_100_000_population`.
- 출처: United Nations Office on Drugs and Crime (2025). 최근 연도 비율과 영국 값은 OWID가 UN WPP 2024 인구로 계산한다고 메타데이터가 적는다. 영국은 잉글랜드·웨일스, 스코틀랜드, 북아일랜드를 합친 값이다. OWID minor processing, CC BY 4.0. UNODC 라이선스는 메타데이터에 다시 적혀 있지 않다.
- 세계은행 `VC.IHR.PSRC.P5` zip은 받아 두기만 했다.

## suicide_rate.csv

- 열: `iso3,year,value`. 단위는 인구 10만 명당 사망. 연령표준화, 남녀 합계, 자해.
- 행 4,268. 코드 194개. 연도 2000–2021.
- 주소: `https://ourworldindata.org/grapher/death-rate-from-suicides-gho.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `death_rate100k__age_group_age_standardized__sex_both_sexes__cause_self_harm`.
- 메타데이터 설명: “Estimated number of age-standardized deaths from self-harm in both sexes, per 100,000 people.” 출처 표기: World Health Organization (2024). OWID major processing, CC BY 4.0. WHO 라이선스는 메타데이터에 다시 적혀 있지 않다.
- 세계은행 `SH.STA.SUIC.P5` zip과 WHO GHO JSON은 `original/`에만 있다.

## democracy_index.csv

- 열: `iso3,year,value`. 선거 민주주의 지수. 0–1 척도이고 단위 표기는 비어 있다.
- 행 29,649. 코드 176개. 연도 1789–2025.
- 주소: `https://ourworldindata.org/grapher/electoral-democracy-index.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `electdem_vdem__estimate_best`.
- 출처: V-Dem (2026), Democracy report. OWID processing, CC BY 4.0. V-Dem 라이선스는 grapher 메타데이터에 다시 적혀 있지 않다.
- 지역 평균(커버리지 70% 규칙)은 ISO3 필터로 빠진다. 나라 값은 그 규칙으로 다시 계산하지 않았다.

## regime_type.csv

- 열: `iso3,year,value`. 값은 체제 이름이다.
- 행 29,594. 코드 176개. 연도 1789–2025. `democracy_index.csv`와 나라-연도 개수가 같지 않다. 빈 쪽을 채우지 않았다.
- 주소: `https://ourworldindata.org/grapher/political-regime.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `regime_row_owid`.
- 출처: V-Dem (2026), Regimes of the World. OWID processing, CC BY 4.0. V-Dem 라이선스는 메타데이터에 다시 적혀 있지 않다.
- 코드는 grapher 설정의 순서대로 바꿨다. 0 Closed autocracy, 1 Electoral autocracy, 2 Electoral democracy, 3 Liberal democracy. 다른 코드는 없었다. 2024년 확인: 중국·조선민주주의인민공화국은 Closed autocracy, 스웨덴은 Liberal democracy.
- OWID는 독립 이전 해를 당시 역사적 실체의 체제로 채운다고 적는다. 방글라데시 1971년 이전이 예시다. 이 파일에는 그 가공이 들어 있다.

## gender_inequality.csv

- 열: `iso3,year,value`. Gender Inequality Index. 별도 단위 없음.
- 행 4,600. 코드 172개. 연도 1990–2023.
- 주소: `https://hdr.undp.org/sites/default/files/2025_HDR/HDR25_Composite_indices_complete_time_series.csv`.
- 출처: UNDP Human Development Report 2025. 파일은 cp1252다. `gii_1990`–`gii_2023`만 녹였다. `gii_rank_2023`은 쓰지 않았다.
- 집계 11행(Very high/High/Medium/Low human development, Arab States, East Asia and the Pacific, Europe and Central Asia, Latin America and the Caribbean, South Asia, Sub-Saharan Africa, World)은 ISO3가 아니라 뺐다.
- 라이선스 문장은 CSV에 없다. 인용: UNDP (2025). Human Development Report 2025: A matter of choice: People and possibilities in the age of AI. New York.

## hdi.csv

- 열: `iso3,year,value`. Human Development Index.
- 행 5,940. 코드 193개. 연도 1990–2023.
- 같은 HDR25 파일의 `hdi_1990`–`hdi_2023`만. `hdi_f_*`, `hdi_m_*`, `hdi_rank_2023`은 쓰지 않았다. 집계 11행은 뺐다.
- 라이선스·인용은 `gender_inequality.csv`와 같다. 한국 1990년 0.738, 2023년 0.937이다.

## adult_height.csv

- 열: `iso3,year,sex,value`. `sex`는 `male` 또는 `female`. 단위는 센티미터. `year`는 측정 연도가 아니라 출생 연도다.
- 행 40,400. 코드 200개. 출생 연도 1896–1996. 성별 칸이 빈 행은 없다.
- 주소: `https://ourworldindata.org/grapher/average-height-by-year-of-birth.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `mean_male_height__cm`, `mean_female_height__cm`.
- 출처: NCD Risk Factor Collaboration (2016), Human height. OWID processing, CC BY 4.0. NCD-RisC 라이선스는 메타데이터에 다시 적혀 있지 않고, 원 사이트는 위에서 말한 대로 열리지 않았다.

## age_first_marriage.csv

- 열: `iso3,year,sex,value`. `sex`는 `male`, `female`. 단위는 세. Singulate mean age at marriage.
- 행 3,452. 코드 226개. 연도 1960–2019.
- 주소: `https://www.un.org/development/desa/pd/sites/www.un.org.development.desa.pd/files/undesa_pd_2019_wmd_marital_status.xlsx` 시트 `SMAM`. 페이지: `https://www.un.org/development/desa/pd/data/world-marriage-data`.
- 출처: United Nations, Department of Economic and Social Affairs, Population Division (2019). World Marriage Data 2019 (POP/DB/Marr/Rev2019). 워크북 안내문은 CC BY 3.0 IGO라고 적는다. `http://creativecommons.org/licenses/by/3.0/igo/`.
- 숫자 ISO 코드는 `original/iso3166.csv`(lukes/ISO-3166-Countries-with-Regional-Codes)로 alpha-3에 대응했다. 대응이 없는 14행은 뺐다. Channel Islands 830이 8행, Kosovo 11578이 2행, Netherlands Antilles 530이 4행이다. 코드를 새로 만들지 않았다.
- `YearStart`와 `YearEnd`가 다른 447행은 한 해로 붙이지 않고 뺐다.
- 같은 나라-연도-성별에 값이 다른 출처가 282개 키 있었다. 고르거나 평균내지 않고 그 키 전체를 뺐다. 값이 같은 중복 43키만 한 행으로 합쳤다.
- 남은 자료 처리 유형은 Census 1,481, Estimate 1,400, Survey 571이다. Estimate는 파일에 발표된 값이라 남겼다. 시트 밖 자료로 SMAM을 다시 계산하지 않았다.
- 첫 다운로드는 HTTP 403이었고, 브라우저형 User-Agent로 다시 받아 파일 25,505,433바이트가 저장됐다.

## mother_age_at_birth.csv

- 열: `iso3,year,value`. 단위는 세. 출산 평균 연령(mean age of childbearing).
- 행 35,787. 코드 237개. 연도 1950–2100.
- WPP 2024 medium 열 `MAC`. 토고 업데이트와 원래 값이 같다. 빈 값 없음. 한국 1950년은 31.252다.
- 라이선스 서술은 population의 WPP 항과 같다.

## working_hours.csv

- 열: `iso3,year,value`. 단위는 노동자 1명당 연간 시간.
- 행 5,063. 코드 130개. 연도 1870–2023.
- 주소: `https://ourworldindata.org/grapher/annual-working-hours-per-worker.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `working_hours_omm`.
- 출처: Feenstra et al., Penn World Table 11.0 (2025); Huberman and Minns (2005). OWID는 1870–1938년을 Huberman and Minns, 그 이후 PWT 지표 `avh` 전체를 이어 붙였다고 적는다. Major processing, CC BY 4.0. 두 원자료 라이선스는 메타데이터에 다시 적혀 있지 않다.

## religion.csv

- 열: `iso3,year,religion,value`. 단위는 퍼센트.
- 행 2,786. 코드 199개. 연도 2010과 2020만. 종교 7개라 199×2×7=2,786이고 빈 칸은 없다.
- `religion` 값: Christians, Jews, Muslims, Hindus, Buddhists, Other religions, Religiously unaffiliated.
- 주소: `https://ourworldindata.org/grapher/share-of-population-by-religious-affiliation.csv?v=1&csvType=full&useColumnShortNames=true`.
- 출처: Pew Research Center (2025), Global Religious Composition Estimates for 2010 and 2020. OWID minor processing, CC BY 4.0. Pew 원자료 라이선스는 메타데이터에 다시 적혀 있지 않다. Pew 사이트 원파일은 계정이 필요해 받지 않았다.
- `religious-composition` 차트는 “어떤 종교든” 한 줄이라 쓰지 않았다.

## mobile_subscriptions.csv

- 열: `iso3,year,value`. 단위는 100명당 가입 건수.
- 행 10,594. 코드 214개. 연도 1960–2024.
- 주소: `https://api.worldbank.org/v2/country/all/indicator/IT.CEL.SETS.P2?downloadformat=csv`. WDI last updated 2026-10-08.
- 지표명: Mobile cellular subscriptions (per 100 people). 제공: World Telecommunication/ICT Indicators Database, International Telecommunication Union (ITU).
- 라이선스: 세계은행 데이터셋 CC BY 4.0. ITU 쪽에 더 좁은 조건이 있는지는 zip이 적지 않는다.
- 집계는 뺐다. `XKX`는 남겼다.

## historical_life_expectancy.csv

- 열: `iso3,year,value`. 단위는 세. 출생 시 기대수명.
- 행 1,988. 코드 85개. 연도 1543–1949. 1950년 이상은 배치 1과 겹치므로 넣지 않았다. 1800년보다 앞선 해도 출처에 있으면 남겼다.
- 주소: `https://ourworldindata.org/grapher/life-expectancy.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `life_expectancy_0`.
- 출처: Riley (2005); Zijdeman et al. (2015); Human Mortality Database (2025); UN WPP (2024). OWID는 1950년 이전 나라 값에서 HMD와 Zijdeman et al.이 겹치면 HMD를 쓰고, 지역은 Riley (2005)를 쓴다고 적는다. Major processing, CC BY 4.0. 각 원자료 라이선스는 메타데이터에 다시 적혀 있지 않다.
- 프랑스 1816년은 40.1년이다. 배치 1의 `life-expectancy` 차트와 같은 계열의 1950년 미만만이다.

## historical_child_mortality.csv

- 열: `iso3,year,value`. 단위는 출생아 100명당 사망이다. 1,000명당으로 바꾸지 않았다.
- 행 2,875. 코드 72개. 연도 1751–1949.
- 주소: `https://ourworldindata.org/grapher/child-mortality.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `child_mortality_rate`.
- 출처: Gapminder (2015); UN Inter-agency Group for Child Mortality Estimation (2025). OWID는 두 출처가 겹치면 UN IGME를 우선한다고 적는다. OWID processing, CC BY 4.0. 원자료 라이선스는 메타데이터에 다시 적혀 있지 않다.
- 프랑스 1816년은 27.32다. 배치 1과 같은 차트의 1950년 미만만이다.

## air_pollution.csv

- 열: `iso3,year,value`. 단위는 연평균 PM2.5, 마이크로그램/세제곱미터. 인구가중 노출이다.
- 행 6,800. 코드 200개. 연도 1990–2023.
- 주소: `https://api.worldbank.org/v2/country/all/indicator/EN.ATM.PM25.MC.M3?downloadformat=csv`. WDI last updated 2026-10-08.
- 지표명: PM2.5 air pollution, mean annual exposure (micrograms per cubic meter). 제공: Global Burden of Disease Study 2023 Air Pollution Exposure Estimates, IHME. 메타데이터는 GHDx 원자료를 받으려면 계정이 필요하다고 적는다. 로그인하지 않았고, 세계은행이 배포한 이 지표를 썼다. date published 2026-01-23, date accessed 2026-04-03.
- 라이선스: 세계은행 데이터셋 조건은 CC BY 4.0이되, 제3자 지표는 다를 수 있다고 한다. IHME 원자료의 별도 조건은 이 zip에 전문이 없다.
- OWID `outdoor-air-pollution-exposure`(IHME 직접 계열)와 합치지 않았다. 그 CSV는 `original/`에만 있다.

## tertiary_enrollment.csv

- 열: `iso3,year,value`. 단위는 고등교육 총취학률, 퍼센트.
- 행 5,353. 코드 203개. 연도 1970–2025.
- 주소: `https://api.worldbank.org/v2/country/all/indicator/SE.TER.ENRR?downloadformat=csv`. WDI last updated 2026-10-08.
- 지표명: School enrollment, tertiary (% gross). 제공: UNESCO Institute for Statistics. 메타데이터는 UIS API, date published 2026-02, date accessed 2026-03-19.
- 라이선스: 세계은행 데이터셋 CC BY 4.0. UIS의 추가 조건은 zip에 없다.
- 같은 이름의 OWID grapher는 찾지 못해 세계은행 파일을 썼다. 집계는 뺐다.

## unemployment_youth.csv

- 열: `iso3,year,value`. 단위는 퍼센트. 15–24세 노동력 대비 실업, ILO 모형 추계.
- 행 6,531. 코드 187개. 연도 1991–2025.
- 주소: `https://api.worldbank.org/v2/country/all/indicator/SL.UEM.1524.ZS?downloadformat=csv`. WDI last updated 2026-10-08.
- 지표명: Unemployment, youth total (% of total labor force ages 15-24) (modeled ILO estimate). 제공: ILO Modelled Estimates database (ILOEST). date accessed January 17, 2026.
- 라이선스: 세계은행 데이터셋 CC BY 4.0. ILO 추가 조건은 zip에 없다.
- `CHI`는 남겼다.

## natural_disaster_deaths.csv

- 열: `iso3,year,value`. 단위는 10만 명당 사망. 모든 자연재해 합계 열만 썼다.
- 행 6,348. 코드 218개. 연도 1900–2025. 이 중 값이 0인 행이 1,674개다. 0은 발표된 값이라 남겼고, 파일에 없는 나라-연도를 0으로 채우지 않았다.
- 주소: `https://ourworldindata.org/grapher/natural-disaster-death-rates.csv?v=1&csvType=full&useColumnShortNames=true`. 열 `total_dead_per_100k_people_all_disasters_yearly`.
- 출처: EM-DAT, CRED / UCLouvain (2026). 인구는 OWID가 “various sources (2024)”로 표시한다. Major processing, 그 가공분은 CC BY 4.0. EM-DAT 자체 라이선스는 메타데이터에 다시 적혀 있지 않다.
- 메타데이터: EM-DAT 사망은 확인된 사망에 실종을 더한다. 가뭄·지진·극한기온·폭풍·홍수·화산·산불·산사태 정의가 같은 설명에 있다. 재해 유형별 비율을 합쳐 총률을 만들지 않았다. 총률 열이 이미 있다.
- 사망 건수 차트 `natural-disasters-deaths`는 `original/owid-natural-disasters-deaths.csv`에만 있다.
