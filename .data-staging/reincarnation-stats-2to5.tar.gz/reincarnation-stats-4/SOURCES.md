# 환생 통계 배치 4 출처

2026-10-13에 받은 원본은 `original/`에 그대로 두었다. 이 디렉터리 바로 아래 CSV만 정규화 결과다. 저장소와 배치 1·2·3 디렉터리는 수정하지 않았다.

공통 규칙:

- `iso3`는 ISO 3166-1 alpha-3만 남겼다. 지역·소득군 합계, 코소보처럼 ISO 코드가 없는 지역, 나라 안 지역(스코틀랜드, 퀘벡 등)은 뺐다. 숫자 코드(M49)와 두 글자 코드는 배치 3의 `original/iso3166.csv`로 바꿨다.
- 빈 값은 넣지 않았고, 연도를 보간하거나 나라 사이를 평균내지 않았다.
- 직접 계산한 값은 두 가지뿐이다. 연평균 기온(12개월 값의 단순 평균)과 월별 출생 비율(그 달 출생 수 ÷ 12개월 합계 × 100). 둘 다 12개월이 모두 있는 해만 계산했다.
- "출생 수 상위 60개국"은 배치 2 `births_by_year.csv`의 2023년 값 순위다(UN WPP 2024).

## 건너뛴 것

- 8번 전기 접근률·안전한 식수 접근률은 배치 3에 `electricity_access.csv`, `safe_water.csv`로 이미 있어 받지 않았다.

## 받지 못했거나 쓰지 않은 것

- UNdata "Live births by month of birth"(인구통계연감 표 55, 60,211행). `https://data.un.org/Handlers/DownloadHandler.ashx?DataFilter=tableCode:55&DataMartId=POP&Format=csv` 가 HTTP 404였다. 사이트가 새 화면으로 바뀌면서 내려받기·페이지 조회 핸들러가 모두 404다. 그래서 월별 출생은 유럽(Eurostat)과 HFD 수록국만 있다.
- 세계은행 `SM.POP.TOTL.ZS`(이주민 비율)는 `original/wb-SM.POP.TOTL.ZS.json`에 받아 두었지만 쓰지 않았다. UN DESA 원본을 썼다.
- WHO GHE 2021·2022년분도 원본을 받아 `cause_of_death_top5.csv`에 연도별로 넣었다. 최신은 2023년이다.
- Wikidata 이름 질의의 첫 시도(라벨을 한 질의에 함께 요청)는 느려서 중단했다. 그때 받은 일부 응답은 `original/wikidata-names-labelled-first-pass/`에 있고 정규화에는 쓰지 않았다.
- 유출된 Facebook 이름 DB나 그 가공본(`names-dataset` 등)은 쓰지 않았다.

## common_names.csv (1번 이름·성)

- 열: `iso3,kind,sex,rank,name,native_label,wikidata_qid,people_count`. `kind`는 `given`(이름)·`family`(성), `sex`는 이름에만 `male`·`female`. 나라마다 남자 이름 30위, 여자 이름 30위, 성 30위. 행 5,400. 코드 60개(2023년 출생 수 상위 60개국 전부). 연도 없음.
- 출처: Wikidata SPARQL `https://query.wikidata.org/sparql`. 국적(P27)이 그 나라인 항목을 이름(P735) 또는 성(P734)별로 세어 많은 순으로 30개. 이름은 성별(P21)이 남성(Q6581097)·여성(Q6581072)인 항목만. 나라별 질의와 응답 원본은 `original/wikidata-names/<ISO3>-<종류>.json`(180개), 영어 라벨과 원어 표기(P1705)는 Wikidata API `wbgetentities`로 받아 `original/wd-name-labels.json`에 두었다.
- 라이선스: CC0 1.0.
- **가장 큰 주의: 이 순위는 인구 통계가 아니다.** `people_count`는 Wikidata에 항목이 있는 인물(정치인·선수·예술인 등, 과거 인물 포함) 수다. 그 나라에서 지금 태어나는 아이 이름 순위와 다르고, 시대·성별·직업이 한쪽으로 쏠린다. 예: 미국 남자 1위 John, 독일 남자 1위 Hans, 일본 여자 1위 Keiko는 옛 세대 이름이다.
- 표본이 작은 나라가 많다. 세 순위 가운데 하나라도 1위의 인물 수가 30명 미만인 나라가 36곳이다(AFG, AGO, BDI, BEN, BFA, BGD, CIV, CMR, COD, DZA, ETH, GHA, IRQ, KEN, MAR, MDG, MMR, MOZ, MWI, MYS, NER, NPL, PAK, SAU, SDN, SOM, SYR, TCD, THA, TZA, UGA, UZB, VNM, YEM, ZMB, ZWE). 이런 나라의 하위 순위는 1–3명 차이라 순위로 읽으면 안 된다.
- 눈에 띄는 잡음: 인도 남자 1위가 머리글자 `K.`, 태국 남자 1위가 Joseph(9명), 모잠비크 성 1위가 여러 낱말로 된 한 항목, 베트남은 가운뎃이름 Thị·Minh이 이름으로 잡힌다. 중국·한국식 이름은 한자 한 글자 단위 항목이 섞인다. 영어 라벨이 없는 항목이 27행 있다(`name`이 비어 있고 `wikidata_qid`만 있음).
- 라벨은 영어 표기다. `native_label`은 Wikidata에 원어 표기가 있을 때만 채워진다.
- 실제 인구 기준 이름 순위가 필요하면 나라별 통계청 자료(미국 SSA, 영국 ONS, 한국 대법원 등)를 따로 받아야 한다. 이번에는 받지 않았다.

## official_languages.csv (2번 공용어)

- 열: `iso3,language,wikidata_qid,iso639_1`. 행 521. 코드 244개. 연도 없음(받은 날 기준 현재 값).
- 출처: Wikidata SPARQL `https://query.wikidata.org/sparql`. 나라(P298 ISO3가 있고 Q6256 국가의 하위 유형)의 공용어(P37) 진술. 종료 시점(P582)이 붙은 진술과 deprecated 등급은 뺐다. 질의 결과 원본은 `original/wd-official-languages.json`.
- 라이선스: CC0 1.0.
- 주의: Wikidata 입력 품질이 나라마다 다르다. 미국은 영어가 없고 Spanish·Hawaiian·Samoan·Chamorro·Carolinian만 나온다(속령·주 단위 진술이 섞임). 한국은 한국수어가 함께 나온다. 수어·지역 공용어를 구분하는 열은 없다. 사이트에 쓰기 전에 출생 상위국은 눈으로 확인해야 한다.
- 배치 2 기준 237개 지역 가운데 4곳이 없다.

## cause_of_death_top5.csv (3번 사망 원인)

- 열: `iso3,year,rank,ghe_cause_code,cause,deaths,deaths_per_100k,share_of_deaths_pct`. 행 2,745(183개국 × 3개 연도 × 5위). 연도 2021–2023.
- 출처: WHO Global Health Estimates, 공개 OData API `https://xmart-api-public.who.int/DEX_CMS/GHE_FULL`. 조건은 `DIM_AGEGROUP_CODE eq 'TOTAL'`, 연도별. 원본은 `original/who-ghe-{2021,2022,2023}-total-age.json`(남·여·합계 모두, 원인 226개).
- 순위는 성별 합계(`DIM_SEX_CODE = TOTAL`)에서 WHO가 순위 대상으로 표시한 원인(`FLAG_RANKABLE = 1`)만 사망 수 내림차순으로 매겼다. 상위 분류("심혈관 질환" 전체 등)는 WHO 표시대로 순위에서 빠진다. 2021–2023년은 COVID-19가 순위에 들어가는 나라가 있다.
- 값은 WHO 추정치이고 사망등록 실측이 아니다.
- 라이선스: **불분명.** API 응답과 메타데이터에 라이선스 문장이 없다. WHO 사이트 일반 조건은 CC BY-NC-SA 3.0 IGO(비상업)로 알려져 있으나 이번에 약관 페이지에서 문장을 확인하지 못했다. 광고가 붙는 사이트에 쓰기 전에 확인이 필요하다.
- WHO 회원국 183개만 있다. 237개 지역 가운데 54곳(주로 속령·소규모 지역)이 없다. 출생 상위 60개국은 모두 있다.

## migrant_share.csv (4번 이주민 비율)

- 열: `iso3,year,value`. 단위는 전체 인구 대비 국제 이주민(외국 출생 또는 외국 국적) 비율(%), 남녀 합계. 행 1,856. 코드 232개. 연도 1990·1995·2000·2005·2010·2015·2020·2024.
- 출처: UN DESA Population Division, International Migrant Stock 2024, Table 3. `https://www.un.org/development/desa/pd/sites/www.un.org.development.desa.pd/files/undesa_pd_2024_ims_stock_by_sex_and_destination.xlsx`
- 라이선스: CC BY 3.0 IGO(파일 안 저작권 줄에 명시).
- 인용: United Nations Department of Economic and Social Affairs, Population Division (2024). International Migrant Stock 2024.
- 지역·소득군 합계 52행과 채널 제도(ISO 코드 없음)는 뺐다. 237개 지역 가운데 5곳이 없다.

## annual_temperature.csv, monthly_temperature.csv (5번 기온)

- `monthly_temperature.csv` 열: `iso3,year,month,value`. 단위 °C. 행 200,720. 코드 193개. 1940년 1월–2026년(받은 날까지 나온 달).
- `annual_temperature.csv` 열: `iso3,year,value`. 행 16,598. 코드 193개. 연도 1940–2025. 12개월 값의 단순 평균을 직접 계산했다(달 길이 가중 없음, 소수 넷째 자리 반올림). 2026년은 12개월이 차지 않아 뺐다.
- 출처: Our World in Data `https://ourworldindata.org/grapher/average-monthly-surface-temperature.csv?v=1&csvType=full&useColumnShortNames=true`. 원자료는 Copernicus Climate Change Service ERA5 monthly averaged data on single levels(지상 2m 기온). OWID가 나라 경계로 잘라 위도 가중 평균을 냈다.
- 라이선스: OWID 가공분 CC BY 4.0. Copernicus 자료는 출처 표기 조건의 자유 이용이며 "Contains modified Copernicus Climate Change Service information (2026)" 문구를 붙여야 한다.
- 주의: 나라 전체 면적 평균이라 인구가 사는 곳의 기온과 다르다(러시아·캐나다·중국 등). OWID는 아주 작은 나라의 값이 부정확할 수 있다고 적는다. 237개 지역 가운데 46곳이 없다.

## household_size.csv (6번 가구원 수)

- 열: `iso3,year,value,source`. 단위는 가구당 평균 가구원 수. 행 1,014. 코드 186개. 연도 1960–2021. `source`는 조사 종류(DHS, DYB, IPUMS, MICS, LFS).
- 출처: UN DESA Population Division, Database on Household Size and Composition 2022. `https://www.un.org/development/desa/pd/sites/www.un.org.development.desa.pd/files/undesa_pd_2022_hh-size-composition.xlsx`
- 라이선스: 파일 안에 라이선스 문장을 확인하지 못했다. UN DESA 인구국의 같은 시기 자료는 CC BY 3.0 IGO지만 이 파일에 대해서는 **미확인**이다.
- 조사 기준일에서 연도만 남겼다. 한 나라·한 해에 조사 종류가 다른 행이 둘 있을 수 있어 `source`로 구분한다. 평균 가구원 수가 `..`인 행과 ISO 코드가 없는 행 45개는 뺐다.
- 빈 곳: 출생 상위 60개국 가운데 사우디아라비아가 없다. 최신 값이 2010년 이전인 나라가 17곳이다(AZE, CHE, CHN, DJI, GNQ, ISR, MYS, NIC, OMN, PNG, PRK, SYC, SYR, TUR, UZB, VEN, VUT). 237개 지역 가운데 51곳이 없다.

## birth_month_share.csv (7번 월별 출생)

- 열: `iso3,year,month,births,share_pct,source`. `births`는 그 달 출생아 수, `share_pct`는 그 해 12개월 합계에서 차지하는 비율(%). 행 25,056. 코드 59개. 연도 1960–2025.
- 출처 1: Eurostat `demo_fmonth`(Live births by month). `https://ec.europa.eu/eurostat/api/dissemination/sdmx/2.1/data/demo_fmonth?format=TSV&compressed=true`. 48개국. 그리스 `EL`→GRC, 영국 `UK`→GBR로 바꿨다. EU 합계, 본토 프랑스(`FX`), 코소보는 뺐다. 값 뒤 플래그 문자(p, e, b 등)는 떼고 숫자만 썼다. 라이선스는 Eurostat 재사용 정책상 출처 표기 조건의 자유 이용(CC BY 4.0)인데, 이번에 약관 페이지 문장은 다시 확인하지 못했다.
- 출처 2: Human Fertility Database, Short-Term Fertility Fluctuations(STFF). `https://www.humanfertility.org/File/GetDocumentFree/STFF/stff.csv`. Eurostat에 없는 11곳만 썼다(AUS, CAN, CHL, GRL, ISR, JPN, KOR, NZL, SGP, TWN, USA). 라이선스 CC BY 4.0(STFF 페이지에 명시). 인용: Max Planck Institute for Demographic Research and Vienna Institute of Demography, Human Fertility Database.
- 12개월이 다 있지 않은 나라·해 43건은 뺐다. 달 길이(28–31일) 보정은 하지 않았다.
- 빈 곳: 출생 상위 60개국 가운데 53곳이 없다. 있는 곳은 미국·일본·러시아·독일·영국·프랑스·튀르키예 7곳뿐이다. 인도·중국·나이지리아 등 아시아·아프리카·중남미 대부분이 비어 있다. UNdata 표 55가 살아나면 다시 받을 수 있다.
