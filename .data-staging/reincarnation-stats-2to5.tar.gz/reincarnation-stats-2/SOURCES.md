# 환생 통계 배치 2

2026-10-13에 받았다. 요청한 여섯 개 원본은 모두 받아졌다. 실패한 다운로드는 없다.

가공 파일은 이 디렉터리에 있고, 받은 원본은 `original/`에 있다. 세계은행 원본은 zip이라 그 안의 데이터 CSV도 `original/`에 풀어 두었다.

나라만 남겼다. UN 세계인구전망은 `LocTypeName`이 Country/Area이고 ISO3가 있는 곳, 세계은행 지표는 국가 API에서 지역이 Aggregates가 아닌 217개 경제다. 대만(TWN)은 세계은행 국가 API에 없어서 문해율·조혼에는 없고, 인구전망·행복·분쟁에는 있다.

## births_by_year.csv

- 원본 URL: https://population.un.org/wpp/assets/Excel%20Files/1_Indicator%20(Standard)/CSV_FILES/WPP2024_Demographic_Indicators_Medium.csv.gz
- 토고 수정본: https://population.un.org/wpp/assets/Excel%20Files/1_Indicator%20(Standard)/WPP2024_CSV_files_update.zip 안의 `WPP2024_Demographic_Indicators_Medium_Update.csv`
- 출처: UN DESA Population Division, World Population Prospects 2024 (2024년 7월 11일 공개). 토고만 2026년 1월 19일 interim update(rev.1)를 덮어썼다. 변이: Medium. 열: `Births`.
- 라이선스: 같은 개정판 출판물 *World Population Prospects 2024: Data Sources* (UN DESA/POP/2024/DC/NO.11, https://population.un.org/wpp/assets/Files/WPP2024_Data_Sources.pdf)는 그 출판물의 그림과 표를 CC BY 3.0 IGO(https://creativecommons.org/licenses/by/3.0/igo/)로 다시 쓸 수 있다고 적는다. CSV 다운로드 화면에는 별도의 라이선스 문장이 없다.
- 행 수: 35,787. 나라 237개.
- 연도: 1950–2100. 나라마다 151년이 모두 있다.
- 값: 한 해 출생아 수(명). 원본 단위는 천 명이라 1,000을 곱했다. 결과는 전부 정수다.
- 이상함: 원본에는 나라마다 2101년 행이 하나 더 있고 출생 칸이 비어 있다. 요청 범위 밖이라 뺐다. 파일 안에는 추계와 전망을 나누는 열이 없다. 2024년 개정판 설명상 최근 추계 뒤는 중위 전망이다. 토고는 151년 중 1950–1964년 15년만 같고, 1965–2100년 136년은 수정본이 다르다. 2023년은 289,759명에서 268,455명으로, 가장 큰 차이는 2081년 417,069명에서 374,799명이다. 수정 zip에는 토고만 들어 있다. 릴리스 노트는 다른 지역은 그대로라고 한다.

## survival_to_age.csv

열은 `iso3,year,age,value`다.

- 원본 URL: https://population.un.org/wpp/assets/Excel%20Files/1_Indicator%20(Standard)/CSV_FILES/WPP2024_Life_Table_Abridged_Medium_1950-2023.csv.gz
- 출처: UN DESA Population Division, World Population Prospects 2024, 간이생명표(abridged), medium. 성별은 Total(남녀 합산). `lx`는 출생 10만 명당 생존자 수.
- 라이선스: 출생 파일과 같다. CC BY 3.0 IGO는 Data Sources 출판물 문장이고, CSV 화면에는 별도 문장이 없다.
- 행 수: 1,659. 나라 237개 × 나이 7개.
- 연도: 모두 2023. 이 파일에서 나라별 최신 연도가 전부 2023이다. 2024–2100 전망 생명표는 받지 않았다. 2026년 1월 수정본에도 생명표는 없다. 토고 생존 비율은 2024년 7월 파일 그대로다.
- 값: 그 해 기간생명표에서 출생 코호트가 그 나이까지 살아 있는 비율. `lx / lx(0)`. `lx(0)`은 237개국 모두 100,000이었다. 나이는 간이표의 정확한 나이(`AgeGrpStart`) 1, 5, 15, 30, 50, 70, 90이다. 반올림은 소수 8자리 half-even이다. 비율은 0과 1 사이이고, 같은 나라에서 나이가 늘면 비율이 줄거나 같다.
- 이상함: 없는 나이·비어 있는 `lx`는 없었다.

## literacy_rate.csv

- 원본 URL: https://api.worldbank.org/v2/en/indicator/SE.ADT.LITR.ZS?downloadformat=csv
- 받은 파일: `original/wb-SE.ADT.LITR.ZS.zip`, 그 안의 `original/API_SE.ADT.LITR.ZS_DS2_en_csv_v2_7054.csv`
- 출처: World Bank World Development Indicators, 지표 SE.ADT.LITR.ZS, 이름 Literacy rate, adult total (% of people ages 15 and above). CSV의 Last Updated Date는 2026-10-08. 세계은행이 적는 원출처는 UNESCO Institute for Statistics. UIS API로 받았고, 세계은행이 기록한 접근일은 2026-03-19, UIS 공개일은 2026-02다.
- 라이선스: 세계은행 데이터셋 이용 조건(https://www.worldbank.org/ext/en/legal/terms-conditions/datasets). 따로 표시되지 않은 데이터셋은 CC BY 4.0(https://creativecommons.org/licenses/by/4.0/)이고, 세계은행과 데이터 제공자를 밝혀야 한다. 이 지표 메타데이터에 다른 라이선스 표시는 없었다.
- 행 수: 1,121. 나라 170개.
- 연도: 1970–2024. 조사 연도만 있다. 나라별 관측은 드문 편이다.
- 값: 15세 이상 성인 문해율(%). 0–100 척도다. 관측 범위는 약 8.83에서 100이다.
- 이상함: 세계은행 CSV는 배정밀도 실수를 길게 적는다. 예를 들어 아루바 2000년은 `97.2900009155273`이다. 그 문자열을 그대로 숫자로 옮겼다. 집계 코드 41개(지역·소득 그룹)는 빼었다.

## child_marriage.csv

- 원본 URL: https://api.worldbank.org/v2/en/indicator/SP.M18.2024.FE.ZS?downloadformat=csv
- 받은 파일: `original/wb-SP.M18.2024.FE.ZS.zip`, 그 안의 `original/API_SP.M18.2024.FE.ZS_DS2_en_csv_v2_3398.csv`
- 출처: World Bank World Development Indicators, 지표 SP.M18.2024.FE.ZS, 이름 Women who were first married by age 18 (% of women ages 20-24). Last Updated Date는 2026-10-08. 세계은행이 적는 원출처는 UNICEF Data, 원지표 코드 PT_F_20-24_MRD_U18(20–24세 여성 중 18세 이전에 결혼하거나 동거를 시작한 비율). 같은 메타데이터에 DHS Program 지표 MA_MBAG_W_B18도 출처로 적혀 있다.
- 라이선스: 문해율과 같다. 세계은행 데이터셋 CC BY 4.0. 이 지표에 다른 라이선스 표시는 없었다.
- 행 수: 428. 나라 146개.
- 연도: 1985–2025. 조사 연도만 있다.
- 값: 20–24세 여성 중 18세 이전 결혼(또는 동거) 비율(%). 관측 범위는 0에서 83.5다.
- 이상함: 집계 코드 28개는 빼었다. 값이 0인 해가 있다.

## happiness.csv

- 원본 URL: https://files.worldhappiness.report/WHR26_Data_Figure_2.1.xlsx
- 안내 페이지: https://www.worldhappiness.report/ed/2026/ 와 https://www.worldhappiness.report/data-sharing/
- 출처: World Happiness Report 2026 (2026년 3월 19일). 편집 John F. Helliwell, Richard Layard, Jeffrey D. Sachs, Jan-Emmanuel De Neve, Lara B. Aknin, Shun Wang. University of Oxford, Wellbeing Research Centre. ISBN 979-8-2513794-7-1. 시트 이름 `Data for Figure 2.1 (2011–2025)`. 값은 열 `Life evaluation (3-year average)`다. 이것은 갤럽 세계여론조사의 Cantril ladder(0–10 삶의 평가) 국가 평균이다.
- 라이선스: 데이터 공유 페이지는 Figure 2.1 자료를 무료로 받을 수 있다고만 적고, Creative Commons 같은 라이선스 이름은 없다. 받은 파일에도 라이선스 속성이 없다. 갤럽 세계여론조사 미시자료는 이 파일에 없고, 별도 신청·구독 대상이다.
- 행 수: 2,103. 나라 165개.
- 연도: 2011, 2012, 2014–2025. 2013년 행은 파일에 없다. 최신 라벨 연도는 2025이고, 2026년 보고서 2장은 이 순위를 2023–2025년 조사의 평균이라고 설명한다. 같은 열 이름이 2011년부터 모든 행에 붙어 있다. 단일 연도 사다리 점수를 담은 다른 열은 없다. 최신 보고서의 이 시계열을 모두 남겼다.
- 값: Cantril ladder 삶의 평가, 3년 평균. 관측 범위는 1.364에서 7.856이다. 핀란드 2025년은 7.764다.
- 이상함: 출판본은 CSV가 아니라 xlsx다. ISO3는 세계은행 나라 이름과 맞췄다. 북한은 이 파일에 없다. 북키프로스 9행, 소말릴란드 4행은 ISO3가 없어 뺐다. 대만은 세계은행 국가 API에 없어서 `Taiwan Province of China`를 TWN으로 넣었다. `Congo`는 콩고 공화국(COG), `DR Congo`는 콩고민주공화국(COD)으로 뒀다. 에스와티니와 옛 이름 스와질란드는 같은 SWZ이고 연도가 겹치지 않았다.

## conflict_deaths_rate.csv

- 원본 URL: https://ourworldindata.org/grapher/death-rate-in-armed-conflicts.csv?v=1&csvType=full&useColumnShortNames=false
- 차트: https://ourworldindata.org/grapher/death-rate-in-armed-conflicts
- 지표 메타데이터: https://api.ourworldindata.org/v1/indicators/1270137.metadata.json
- 출처: Our World in Data가 가공한 Uppsala Conflict Data Program. 지표 메타데이터의 데이터셋 이름은 `UCDP, History of war`, 버전 2026-06-10. 원계열은 UCDP Georeferenced Event Dataset v26.1(https://ucdp.uu.se/downloads/index.html#ged_global, 공개 2026, OWID 접근 2026-06-10). 나라 경계는 geoBoundaries CGAZ 6.0.0(2023-09-14). 인구 분모는 OWID가 여러 출처로 만든 인구(https://ourworldindata.org/population-sources, 2024-07-15 공개, 접근 2026-03-31). 열은 `Death rate in ongoing conflicts (best estimate) - Conflict type: all`. 단위는 인구 10만 명당 사망이다. 전투원과 민간인, 국가 간·내전·비국가·일방적 폭력·구식민 분쟁을 포함하고, UCDP의 best estimate다. 사망은 죽은 사람의 국적이 아니라 deaths가 난 장소에 붙는다.
- 라이선스: 지표 메타데이터는 UCDP GED v26.1, geoBoundaries, 인구 분모를 각각 CC BY 4.0(https://creativecommons.org/licenses/by/4.0/)으로 적는다. OWID 가공본도 출처를 밝히는 CC BY다.
- 행 수: 7,326. 나라 198개. 나라마다 1989–2025년 37년이 모두 있다.
- 연도: 1989–2025.
- 값: 인구 10만 명당 사망. 그중 5,601행은 0이다. 0은 결측이 아니라 파일에 적힌 값이다. 가장 큰 값은 르완다 1994년 11,371.795다. 단위가 10만 명당이라 100을 넘을 수 있다.
- 이상함: 코소보 코드가 `OWID_KOS`라 세계은행 코드 XKX로 바꿨다(37행). 대만(TWN)과 서사하라(ESH)는 ISO3가 있어 남겼다. 이 둘은 세계은행 국가 API 217개에는 없다. 지역 합계(World, Africa, Americas, Asia and Oceania, Europe, Middle East)와 옛 정치체(체코슬로바키아, 동독, 서독, 예멘 인민민주공화국, 유고슬라비아)는 뺐다.

## 원본 파일

- `original/WPP2024_Demographic_Indicators_Medium.csv.gz`
- `original/WPP2024_Demographic_Indicators_notes.csv`
- `original/WPP2024_CSV_files_update.zip`
- `original/WPP2024_Life_Table_Abridged_Medium_1950-2023.csv.gz`
- `original/wb-SE.ADT.LITR.ZS.zip`
- `original/API_SE.ADT.LITR.ZS_DS2_en_csv_v2_7054.csv`
- `original/wb-SP.M18.2024.FE.ZS.zip`
- `original/API_SP.M18.2024.FE.ZS_DS2_en_csv_v2_3398.csv`
- `original/WHR26_Data_Figure_2.1.xlsx`
- `original/death-rate-in-armed-conflicts.csv`
- `original/death-rate-in-armed-conflicts.metadata.json`
- `original/owid-ucdp-1270137.metadata.json`
- `original/wb-countries.json`
- `original/wb-SE.ADT.LITR.ZS.meta.json`
- `original/wb-SP.M18.2024.FE.ZS.meta.json`
